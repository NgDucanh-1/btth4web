﻿using Microsoft.AspNetCore.Mvc;
using baithuchanhview.Models; 

namespace baithuchanhview.ViewComponents
{
    public class HotProductViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            var hotProducts = new List<ProductModel>
            {
                new ProductModel { Id = 4, Name = "Nồi cơm điện cao tần Nagakawa NAG0102" },
                new ProductModel { Id = 5, Name = "Nồi cơm điện cao tần Nagakawa NAG0102" },
                new ProductModel { Id = 6, Name = "Nồi cơm điện cao tần Nagakawa NAG0102" }
            };
            return View(hotProducts);
        }
    }
}