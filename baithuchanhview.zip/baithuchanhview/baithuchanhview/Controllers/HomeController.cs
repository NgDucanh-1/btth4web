using baithuchanhview.Models;
using Microsoft.AspNetCore.Mvc;

namespace DemoWebMVC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var listProducts = new List<ProductModel>
            {
                new ProductModel { Id = 1, Name = "Nồi cơm điện cao tần Nagakawa NAG0102", Price = 1500000 },
                new ProductModel { Id = 2, Name = "Nồi cơm điện cao tần Nagakawa NAG0102", Price = 1500000 },
                new ProductModel { Id = 3, Name = "Nồi cơm điện cao tần Nagakawa NAG0102", Price = 1500000 }
            };
            return View(listProducts);
        }
    }
}